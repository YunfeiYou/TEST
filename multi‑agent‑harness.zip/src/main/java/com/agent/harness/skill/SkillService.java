package com.agent.harness.skill;

import com.agent.harness.mcp.McpService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;

/**
 * 3. Skill能力与工具层
 * 搜索、计算、数据库查询、API调用、文件处理、数据分析等原子能力
 */
@Service
public class SkillService {
    @Resource
    private McpService mcpService;

    public String executeSkill(String task) {
        String mcpResult = mcpService.connectStandard(task);
        return "【Skill工具执行】" + mcpResult + "，完成原子能力调用";
    }
}