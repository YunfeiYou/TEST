package com.agent.harness.mcp;

import com.agent.harness.llm.LlmService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;

/**
 * 2. MCP连接与标准层
 * 统一协议、能力发现、安全认证、数据规范，标准化接入外部服务
 */
@Service
public class McpService {
    @Resource
    private LlmService llmService;

    public String connectStandard(String task) {
        String llmResult = llmService.analyzeTask(task);
        return "【MCP标准化连接】" + llmResult;
    }
}