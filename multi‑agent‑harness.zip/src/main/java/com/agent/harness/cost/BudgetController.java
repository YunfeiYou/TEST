package com.agent.harness.cost;

import org.springframework.stereotype.Service;

/**
 * 成本管控模块
 * Token预算、成本熔断、用量统计、阈值管控
 */
@Service
public class BudgetController {
    public String calcTokenCost() {
        return "✅ Token成本管控正常，预算消耗在阈值范围内";
    }
}