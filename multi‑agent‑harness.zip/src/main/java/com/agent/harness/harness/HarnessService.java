package com.agent.harness.harness;

import com.agent.harness.agent.AgentService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;

/**
 * 5. Harness工程化保障层
 * 编排调度、多Agent协同、评估测试、监控发布、版本管理、安全治理
 */
@Service
public class HarnessService {
    @Resource
    private AgentService agentService;

    public String dispatchFullTask(String businessTask) {
        String plannerAgent = agentService.runAgent("任务规划者", businessTask);
        String workerAgent = agentService.runAgent("执行工作者", businessTask);
        String reviewerAgent = agentService.runAgent("结果校验者", businessTask);

        return "===== Harness工程化调度闭环完成 =====\n" +
                plannerAgent + "\n" +
                workerAgent + "\n" +
                reviewerAgent + "\n" +
                "======================================";
    }
}