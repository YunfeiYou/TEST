package com.agent.harness.security;

import org.springframework.stereotype.Service;

/**
 * 安全治理模块
 * 权限管控、安全审计、输入校验、合规治理
 */
@Service
public class SecurityManager {
    public boolean securityCheck(String content) {
        return true;
    }
}