package com.agent.harness.agent;

import com.agent.harness.skill.SkillService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;

/**
 * 4. Agent决策与执行层
 * 任务理解、规划拆解、工具选择、执行行动、结果校验、反思优化
 */
@Service
public class AgentService {
    @Resource
    private SkillService skillService;

    public String runAgent(String agentRole, String task) {
        String skillResult = skillService.executeSkill(task);
        return "【" + agentRole + " Agent】执行：" + skillResult;
    }
}