package com.agent.harness.memory;

import org.springframework.stereotype.Service;

/**
 * 记忆治理模块
 * 短期记忆、长期记忆、向量检索、会话状态管理
 */
@Service
public class MemoryManager {
    public String storeMemory(String memoryContent) {
        return "✅ 记忆持久化完成：" + memoryContent;
    }
}