package com.agent.harness;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Multi‑Agent Harness 生产级框架启动入口
 * 严格对应五层架构：LLM → MCP → Skill → Agent → Harness
 */
@SpringBootApplication
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
        System.out.println("===== Multi‑Agent Harness 框架启动成功 =====");
        System.out.println("✅ LLM认知层 | MCP连接层 | Skill能力层 | Agent执行层 | Harness工程层 全部加载完成");
        System.out.println("✅ 调度、协同、工具、记忆、监控、安全、成本管控模块已就绪");
    }
}