package com.agent.harness.tool;

import org.springframework.stereotype.Service;

/**
 * 工具注册与管理模块
 * 工具注册、Schema校验、权限控制、调用管控
 */
@Service
public class ToolRegistry {
    public String registerAndInvoke(String toolName) {
        return "✅ 工具[" + toolName + "]注册成功，调用执行完成";
    }
}